clear; close all

% Add path to GPstuff toolbox
GPpath = genpath('/./gpstuff-develop'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

system('killall -9 comsollauncher java'); % kill previous running Comsol server instances to prevent port assignment problems

% Load workspace to give us classifier and parameter bounds
load('GPInitialDesign_narrowRanges.mat')

l = l.*sc; u = u.*sc;

global count gp_class_c x_class_c y_class_c count_vec_betIter count_prev

count = 0;
gp_class_c = gp_class;
x_class_c = x_class;
y_class_c = y_class;

count_vec_betIter = []; % vector holding no of fct evaluations between iterations (for fct and gradient evaluations)
count_prev = 0;

X = sobolset(nd, 'Skip',1.4e10,'Leap',0.2e16);

m_drug_values = l(1) + (u(1)-l(1)) * X(:,1);
D_coat_values = l(2) + (u(2)-l(2)) * X(:,2);
h_coat_values = l(3) + (u(3)-l(3)) * X(:,3);

param0 = [m_drug_values'; D_coat_values'; h_coat_values']';

param0 = param0./sc;

%% Run optimization and store output in structure array
% One structure for every different parameter initialisation
% nrun = 5;
% delete(gcp('nocreate'))
% parpool('local', nrun)
tic()
i = 1;
addpath('/maths/comsol56/multiphysics/mli')

comsolPort = 2035+i; % set unique port
system( ['comsol -np 1 server -port ',num2str(comsolPort), ' &'] ); % start a Comsol server
pause( 20 ) % give Comsol server time to start up
% instead of the above, I should try the ID file writing

mphstart(comsolPort); % comsolPort is the port number

OptimHistory = GradientAlgorithm(param0(i,:), l, u, sc, th, i);

time=toc();
save(sprintf('historySQPoptimisation %d.mat',i))
exit;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; close all

i=1;

load(sprintf('historySQPoptimisation %d.mat',i))

param_SQP = OptimHistory.x(end,:) .* sc;
fval_SQP = OptimHistory.fval(end);

xp = cumsum(count_vec_betIter);

figure(1); clf(1)
plot(0:xp(1), repmat(OptimHistory.fval(1),count_vec_betIter(1)+1,1),'-k')
hold on
plot([xp(1) xp(1)],[OptimHistory.fval(2) OptimHistory.fval(1)],'-k')
for j=2:5
    hold on
    plot(xp(j-1):xp(j), repmat(OptimHistory.fval(j),count_vec_betIter(j)+1,1),'-k')
    if j<5
        plot([xp(j) xp(j)],[OptimHistory.fval(j) OptimHistory.fval(j+1)],'-k')
    end
end

load('BayesianOptimisationResults_UCB_narrowRanges.mat')
% add the iterations from the initial design
bestInd=find(min(globalOptimaY)==globalOptimaY);
bestX = globalOptimaX(bestInd,:);
bestY = min(globalOptimaY);

param_BO_UCB = bestX .* sc;
fval_BO_UCB = bestY;

figure(1); hold on
plot(1:(i1+size(X,1)), [NaN(size(X,1),1); [y_regr(size(X,1),1)*std_y+mean_y globalOptimaY]'],'-r')

xlabel('No of forward evaluations'); ylabel('Objective function')