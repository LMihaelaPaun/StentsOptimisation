%%%%%%%%%%%%%%%%%
%%%%%% Run Bayesian Optimization on the stents problem %%%%%
%%% Mihaela Paun %%%

clear; close all;

%system('killall -9 comsollauncher java'); % kill previous running Comsol server instances to prevent port assignment problems

% Add path to GPstuff toolbox
GPpath = genpath('/./gpstuff-develop'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

%% SECTION 1: Run the model for a number of parameter values from a space filling design

th = 150; % modify this threshold value for the drug content DC value
% lower and upper bounds for the drug mass, stent coating and diffusion
% coefficient
%         l = [5, 1e-18, 1];
%         u = [25, 1e-13, 10];
l = [5, 1e-18, 7];
u = [10, 1e-16, 10];

nd = 3; % no of parameters

for irun = 1:1
    
    if 0
        
        clearvars -except l u nd th irun
        
        if irun==1
            X = sobolset(nd, 'Skip',1.4e4,'Leap',0.15e15); % produces 61
        elseif irun==2
            X = sobolset(nd, 'Skip',1.5e4,'Leap',0.18e15); % produces 51
        elseif irun==3
            X = sobolset(nd, 'Skip',1.6e4,'Leap',0.22e15); % produces 41
        elseif irun==4
            X = sobolset(nd, 'Skip',1.7e4,'Leap',0.3e15); % produces 31
        else %irun==5
            X = sobolset(nd, 'Skip',1.8e4,'Leap',0.45e15); % produces 21
        end
        
        m_drug_values = l(1) + (u(1)-l(1)) * X(:,1);
        D_coat_values = l(2) + (u(2)-l(2)) * X(:,2);
        h_coat_values = l(3) + (u(3)-l(3)) * X(:,3);
        
        param = [m_drug_values, D_coat_values, h_coat_values];
        
        success = NaN(size(X,1),1); % records whether we have a simulation that runs successfully,
        % i.e. no convergence issues, no Matlab getting stuck
        norm_areaRs2 = NaN(size(X,1),1); % stores objective function values
        DCmax = NaN(size(X,1),1); % stores the max drug content value
        conSatisf = NaN(size(X,1),1); % indicator vector for whether constraint is satisfied
        
        nrun = 12;%size(X,1); % does not work for 14
        
        delete(gcp('nocreate'))
        
        pool = parpool('local',nrun); % open local pool with nrun Workers
        
        % start the comsol servers
        parfor j=1:nrun
            addpath('/maths/comsol56/multiphysics/mli')
            comsolPort = 2035+j; % set unique port
            system( ['comsol -np 1 server -port ',num2str(comsolPort), ' &'] ); % start a Comsol server
            pause( 30 ) % give Comsol server time to start up
            % instead of the above, I should try the ID file writing
            mphstart(comsolPort); % comsolPort is the port number
        end
        
        parfor i=1:size(X,1)
            
            
            % Get the objective function: normalised area above the RS2 curve --> TO MINIMISE
            % and the maximum drug content value for constraint optimisation (this will need to be below a threshold of 150)
            % and check if the simulation was successful
            [norm_areaRs2(i), DCmax(i), conSatisf(i), success(i)] = Run_Comsol_Simulator(param(i,:), th);
            
            
        end
        
        save(sprintf('GPInitialDesign_narrowRanges %d.mat',irun))
        
        %% SECTION 2: Construct initial GP model out of the simulator callings above
        
        sc = abs(u);
        
        l = l./sc; u = u./sc;
        
        conSatisf = logical(conSatisf);
        
        % Construct classifier
        x_class = param./sc; y_class = 2.*conSatisf-1;
        % For GP regr only look successful simulations from simulator
        x_regr = param(conSatisf,:)./sc; y_regr = norm_areaRs2(conSatisf);
        
        %%%
        
        mean_y = mean(y_regr);
        std_y = std(y_regr);
        
        % Scale y_regr
        y_regr = (y_regr-mean_y)./std_y; % mean 0 and std 1 of of y
        
        % Build GP models (regression emulator for normalised area above Rs2)
        % and classifier for upper constraint on DC max value
        
        X_r = sobolset(nd+2, 'Skip',2e12,'Leap',0.45e15); % draw 10 values
        n_r = size(X_r, 1);
        
        l_r = [0.5 repmat(0.1,1,nd) 10^(-6)];
        u_r = [1.5 ones(1,nd) 1];
        
        % Initialisations for amplitude, lengthscale and likelihood noise for GP
        % regression
        H_r = [];
        for i=1:nd+2
            H_r = [H_r, l_r(i) + (u_r(i)-l_r(i)) * X_r(:,i)];
        end
        
        % Initialisations for amplitude and lengthscale for GP classification
        X_c = sobolset(nd+1, 'Skip',4e8,'Leap',0.45e15); % draw 21 values
        n_c = size(X_c, 1);
        
        l_c = [0.5 repmat(0.1,1,nd)];
        u_c = [1.5 ones(1,nd)];
        
        H_c = [];
        for i=1:nd+1
            H_c = [H_c, l_c(i) + (u_c(i)-l_c(i)) * X_c(:,i)];
        end
        
        [gp_regr, nlml_regr, gp_class, nlml_class] = ...
            GPmodel_BO100(x_regr, y_regr, x_class, y_class, H_r, H_c);
        
        [w,s] = gp_pak(gp_regr);
        disp(exp(w))
        
        [w,s] = gp_pak(gp_class);
        disp(exp(w))
        
        %Make predictions using gp_regr
        [E, Var] = gp_pred(gp_regr, x_regr, y_regr, x_regr);
        
        figure(1); clf(1);
        plot(E,E,'-r','linewidth',2);hold on;
        plot(E, y_regr, 'ob','markersize',6,'markerfacecolor',[0 0 1]);
        set(gca,'fontsize',20);grid on;
        xlabel('Train data'); ylabel('Predictions')
        
        % Make predictions using gp_class
        [Eft_la, Varft_la, lpyt_la, Eyt_la, Varyt_la] = ...
            gp_pred(gp_class, x_class, y_class, x_class, ...
            'yt', ones(size(x_class,1),1) );
        figure(2); clf(2)
        % if good classifier, 2 dots on the plot: one at (0,-1) & another at (1,1)
        plot(exp(lpyt_la), y_class, 'or', 'markersize', 8,'markerfacecolor',[1 0 0])
        set(gca,'fontsize',20); grid on;
        xlabel('Predictions'); ylabel('Train labels')
        
        save(sprintf('GPInitialDesign_narrowRanges %d.mat',irun))
        
    end
    
    %% SECTION 3: Carry out BO
    
    load(sprintf('GPInitialDesign_narrowRanges %d.mat',irun))
    
    tol = 0.01;
    
    i1 = 1;
    maxiter = 91-size(X,1); % budget (maximum no of function evaluations)
    improv = inf;   % improvement between two successive query points
    
    % Set the options for optimizer of the acquisition function
    
    opts = optimoptions(@fmincon,'Algorithm','active-set');
    
    globalOptimaY = []; % stores all the global optima y (obj fct) points that satisfy the constraint DC max<T
    globalOptimaX = []; % stores all the global optima x (param) points that satisfy the constraint DC max<T
    
    DCmax_BO = NaN(maxiter,1);
    norm_aRs2 = NaN(maxiter,1);
    
    delta = 0.1; % needed for UCB calculation
    
    min_idx = 1; % we minimise the true fct (area above the curve)
    
    count = 0; % total no of iterations (includes those that progress or not the obj fct)
    
    count_prev = 0; % no of model evaluations at the previous step when the obj fct progressed
    
    %i1 no of iterations which progress the objective function
    
    count_betIter = []; % vector holding no of model evaluations between iterations that progress the obj fct
    
    % start the comsol servers
    addpath('/maths/comsol56/multiphysics/mli')
    comsolPort = 2041; % set unique port
    system( ['comsol -np 1 server -port ',num2str(comsolPort), ' &'] ); % start a Comsol server
    pause( 30 ) % give Comsol server time to start up
    % instead of the above, I should try the ID file writing
    mphstart(comsolPort); % comsolPort is the port number
    
    %while i1 < maxiter && improv>1e-6
    while count < maxiter && improv>1e-6
        count = count + 1;
        
        % Train the GP model for objective function and calculate variables
        % that are needed when calculating the Expected improvement
        % (Acquisition function)
        
        if i1>1
            gp_regr = gp_optim(gp_regr,x_regr,y_regr);
            gp_class = gp_optim(gp_class,x_class,y_class);
        end
        
        [K, C] = gp_trcov(gp_regr,x_regr);
        invC = inv(C);
        a = C\y_regr;
        
        % The function handle to the hidden-constraints weighed UCB function
        betai1 = 2*log((pi^2*(i1+1)^(nd/2+2))/(3*delta));
        fh_ucb = @(x_new) ucb_hcw(x_new, gp_regr, x_regr, a, invC, ...
            gp_class, x_class, y_class, betai1, y_regr, min_idx);
        
        
        Xo = lhsdesign(1,nd);
        xstart = NaN(size(Xo,1),nd);
        for j=1:nd
            xstart(:,j) = l(j) + (u(j)-l(j)) * Xo(:,j); % starting values for the BO algorithm
        end
        
        problem = createOptimProblem('fmincon','objective',...
            fh_ucb,'x0',xstart,'lb',l,'ub',u,'options',opts);
        
        
        gs = GlobalSearch;
        bestX = run(gs,problem);
        
        
        % calculate the obj fct value at query point by evaluating simulator
        [norm_aRs2(i1), DCmax_BO(i1), conS] = Run_Comsol_Simulator(bestX.*sc,th);
        
        if conS == 1 % successful simulation
            % put new sample point to the list of evaluation regression points
            x_regr(end+1,:) = bestX;
            y_regr = y_regr.*std_y+mean_y; % un-scale
            y_regr(end+1) = norm_aRs2(i1); % on original scale
            mean_y = mean(y_regr); std_y = std(y_regr); % new mean and std
            
            y_regr = (y_regr-mean_y)./std_y; % scale back
            
            globalOptimaY = [globalOptimaY norm_aRs2(i1)]; % y on original scale it's okay
            globalOptimaX = [globalOptimaX; bestX.*sc]; % x on original scale
            
            disp('successful')
            
        else
            disp('unsuccessful')
        end
        
        
        
        % put new sample point to the list of evaluation classification points
        x_class(end+1,:) = bestX; y_class(end+1) = 2.*conS-1;
        
        
        if conS == 1 % check only for the global minima from current and previous BO iteration
            if i1>1
                improv = abs(globalOptimaY(end)-globalOptimaY(end-1)); %abs(y_regr(end) - y_regr(end-1));
            end
            
            i1 = i1 + 1;
            
            count_betIter = [count_betIter count - count_prev];
            
            count_prev = count;
            
        else % consS(1) = 0
            disp('Try another iteration to optimise!')
            i1 = i1; % we do not increment counter for PDE evaluations
        end
        
        [i1, count]
        
        save(sprintf('BayesianOptimisationResults_UCB_narrowRanges_global %d.mat',irun))
        
    end
    
    save(sprintf('BayesianOptimisationResults_UCB_narrowRanges_global %d.mat',irun))
    
end

exit;