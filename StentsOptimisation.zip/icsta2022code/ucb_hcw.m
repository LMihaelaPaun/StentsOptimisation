function [UCB_HCW,UCB] = ucb_hcw(x_new, gp, x, gp_class, x_class, ...
    y_class, beta, y, mean_y, std_y, min_idx)

% Calculate upper confidence bound acquisition fct

[Ef, Varf] = gp_pred(gp, x, y, x_new);

Ef = Ef.*std_y+mean_y;
Varf = Varf.*(std_y^2);
    
% maximise f(x) true function
% i.e. maximise Ef +  beta .* sqrt(Varf), as Ef stands for f(x), and so
% we maximise Ef and also Varf
%
% minimise f(x) true fct
% i.e. minimise Ef -  beta .* sqrt(Varf), as Ef stands for f(x), and so
% we minimise Ef and also -Varf
%
%
if min_idx == 1 % we minimise f(x) true fct
    UCB = Ef -  beta .* sqrt(Varf); % minimise this
else % we maximise f(x) true fct
    UCB = Ef +  beta .* sqrt(Varf); % maximise this
    UCB = -UCB; % minimise this   
end

[~, ~, lpyt_la, ~, ~] = gp_pred(gp_class, x_class, ...
    y_class, x_new, 'yt', ones(size(x_new,1),1));

if isnan(lpyt_la) % a prediction can occasionally be NaN
    
    UCB_HCW = inf;
    
else
    % hidden (inequality) constraint UCB
    
    UCB_HCW = exp(lpyt_la).*UCB; % we want to minimise this
    
end

end